// 测试脚本包的主入口文件
function main(routeParams) {
  const { keyword = 'test', limit = 10 } = routeParams;
  
  return {
    title: `测试脚本包 - ${keyword}`,
    description: '这是一个测试脚本包，验证自动读取package.json中main字段的功能',
    link: 'https://example.com',
    items: Array.from({ length: parseInt(limit) }, (_, i) => ({
      title: `测试项目 ${i + 1} - ${keyword}`,
      description: `这是第${i + 1}个测试项目，关键词：${keyword}`,
      link: `https://example.com/item/${i + 1}`,
      pubDate: new Date(Date.now() - i * 3600000).toISOString() // 每小时间隔
    }))
  };
}

module.exports = { main };