// 示例脚本包 - 主入口文件
const { parseData } = require('./utils/parser');
const { formatItems } = require('./utils/formatter');
const { API_CONFIG } = require('./config/constants');

// 获取路由参数
const { keyword = 'javascript', limit = 10 } = routeParams;

// 构建API URL
const apiUrl = `${API_CONFIG.BASE_URL}/search?q=${encodeURIComponent(keyword)}&per_page=${limit}`;

// 获取数据
const response = await utils.fetchApi(apiUrl);
const rawData = response.data;

// 解析数据
const parsedData = parseData(rawData);

// 格式化为RSS项目
const items = formatItems(parsedData, limit);

// 返回RSS格式数据
return {
  title: `${keyword} 搜索结果`,
  description: `关于 ${keyword} 的最新搜索结果`,
  link: apiUrl,
  items: items
};