/**
 * 配置常量模块
 */

// API配置
const API_CONFIG = {
  BASE_URL: 'https://api.github.com',
  TIMEOUT: 30000,
  USER_AGENT: 'FeedHub-ScriptPackage/1.0'
};

// 默认参数
const DEFAULT_PARAMS = {
  LIMIT: 10,
  MAX_LIMIT: 50,
  DEFAULT_KEYWORD: 'javascript'
};

// 支持的搜索类型
const SEARCH_TYPES = {
  REPOSITORIES: 'repositories',
  ISSUES: 'issues',
  USERS: 'users',
  COMMITS: 'commits'
};

// 排序选项
const SORT_OPTIONS = {
  BEST_MATCH: 'best-match',
  STARS: 'stars',
  FORKS: 'forks',
  UPDATED: 'updated',
  CREATED: 'created'
};

// 错误消息
const ERROR_MESSAGES = {
  INVALID_KEYWORD: '搜索关键词不能为空',
  API_ERROR: 'API请求失败',
  PARSE_ERROR: '数据解析失败',
  NETWORK_ERROR: '网络连接失败'
};

// 缓存配置
const CACHE_CONFIG = {
  TTL: 300, // 5分钟
  MAX_SIZE: 100
};

module.exports = {
  API_CONFIG,
  DEFAULT_PARAMS,
  SEARCH_TYPES,
  SORT_OPTIONS,
  ERROR_MESSAGES,
  CACHE_CONFIG
};