/**
 * 数据格式化工具模块
 */

/**
 * 格式化数据为RSS项目
 * @param {Array} items - 解析后的数据数组
 * @param {number} limit - 限制返回的项目数量
 * @returns {Array} RSS格式的项目数组
 */
function formatItems(items, limit = 10) {
  return items
    .slice(0, limit)
    .map(formatSingleItem)
    .filter(item => item.title && item.link); // 过滤掉无效项目
}

/**
 * 格式化单个项目
 * @param {Object} item - 单个数据项
 * @returns {Object} RSS格式的项目
 */
function formatSingleItem(item) {
  return {
    title: cleanText(item.title),
    link: item.url,
    description: formatDescription(item.description, item.tags),
    pubDate: new Date(item.publishDate),
    author: item.author,
    guid: item.url || item.id,
    categories: item.tags || []
  };
}

/**
 * 清理文本内容
 * @param {string} text - 原始文本
 * @returns {string} 清理后的文本
 */
function cleanText(text) {
  if (!text) return '';
  
  return text
    .replace(/<[^>]*>/g, '') // 移除HTML标签
    .replace(/\s+/g, ' ')    // 合并多个空格
    .trim();
}

/**
 * 格式化描述内容
 * @param {string} description - 原始描述
 * @param {Array} tags - 标签数组
 * @returns {string} 格式化后的描述
 */
function formatDescription(description, tags = []) {
  let formatted = cleanText(description);
  
  // 限制描述长度
  if (formatted.length > 300) {
    formatted = formatted.substring(0, 300) + '...';
  }
  
  // 添加标签信息
  if (tags.length > 0) {
    const tagString = tags.slice(0, 5).join(', ');
    formatted += `\n\n标签: ${tagString}`;
  }
  
  return formatted;
}

/**
 * 格式化日期
 * @param {string|Date} date - 日期
 * @returns {Date} 格式化后的日期对象
 */
function formatDate(date) {
  if (!date) return new Date();
  
  const parsed = new Date(date);
  return isNaN(parsed.getTime()) ? new Date() : parsed;
}

module.exports = {
  formatItems,
  formatSingleItem,
  cleanText,
  formatDescription,
  formatDate
};