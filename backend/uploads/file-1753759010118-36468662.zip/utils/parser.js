/**
 * 数据解析工具模块
 */

/**
 * 解析API响应数据
 * @param {Object} data - 原始API数据
 * @returns {Array} 解析后的数据数组
 */
function parseData(data) {
  // 处理不同的数据结构
  if (data.items) {
    return data.items.map(parseItem);
  }
  
  if (data.results) {
    return data.results.map(parseItem);
  }
  
  if (Array.isArray(data)) {
    return data.map(parseItem);
  }
  
  // 如果是单个对象，包装成数组
  return [parseItem(data)];
}

/**
 * 解析单个数据项
 * @param {Object} item - 单个数据项
 * @returns {Object} 标准化的数据项
 */
function parseItem(item) {
  return {
    id: item.id || item.node_id || generateId(),
    title: item.title || item.name || item.full_name || '无标题',
    description: item.description || item.body || item.summary || '',
    url: item.html_url || item.url || item.link || '#',
    author: item.owner?.login || item.user?.login || item.author || '未知作者',
    publishDate: item.created_at || item.updated_at || item.published_at || new Date().toISOString(),
    tags: item.topics || item.labels || [],
    score: item.score || 0
  };
}

/**
 * 生成唯一ID
 * @returns {string} 唯一标识符
 */
function generateId() {
  return Math.random().toString(36).substr(2, 9);
}

module.exports = {
  parseData,
  parseItem
};